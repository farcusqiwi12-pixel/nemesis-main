import { Router, type IRouter } from "express";
import { gt, desc, eq, sql } from "drizzle-orm";
import { db, chatMessagesTable, chatProfilesTable } from "@workspace/db";
import { z } from "zod/v4";
import {
  ChatMessage,
  CreateChatMessageBody,
  CreateChatMessageResponse,
  GetChatPresenceResponse,
  UpdateChatTypingBody,
  JoinChatBody,
  JoinChatResponse,
  ListChatMessagesQueryParams,
  ListChatMessagesResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

type ActiveParticipant = { name: string; lastSeen: number; typing: boolean };
const participants = new Map<string, ActiveParticipant>();
const PARTICIPANT_TTL_MS = 90_000;
const MAX_AVATAR_LENGTH = 700_000;

const profileBody = z.object({
  sessionId: z.string().min(8).max(80), name: z.string().min(1).max(24),
  bio: z.string().max(280).default(""), avatar: z.string().max(MAX_AVATAR_LENGTH).nullable().optional(),
  accent: z.string().regex(/^#[0-9a-fA-F]{6}$/).default("#d94b72"), emoji: z.string().max(8).default("🙂"),
});
const developerBody = z.object({ sessionId: z.string().min(8).max(80), key: z.string().min(1).max(200) });
const roleBody = z.object({ actorSessionId: z.string().min(8).max(80), targetSessionId: z.string().min(8).max(80), role: z.enum(["user", "moderator"]) });
const deleteBody = z.object({ sessionId: z.string().min(8).max(80) });

async function ensureSchema() {
  await db.execute(sql`CREATE TABLE IF NOT EXISTS chat_profiles (session_id TEXT PRIMARY KEY, name TEXT NOT NULL, bio TEXT NOT NULL DEFAULT '', avatar TEXT, accent TEXT NOT NULL DEFAULT '#d94b72', emoji TEXT NOT NULL DEFAULT '🙂', role TEXT NOT NULL DEFAULT 'user', created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
  await db.execute(sql`ALTER TABLE chat_messages ADD COLUMN IF NOT EXISTS author_session_id TEXT`);
  await db.execute(sql`ALTER TABLE chat_messages ADD COLUMN IF NOT EXISTS reply_to_id INTEGER`);
}
const schemaReady = ensureSchema().catch((error) => { console.error("Anochat schema init failed", error); throw error; });
router.use(async (_req, _res, next) => { try { await schemaReady; next(); } catch { next(new Error("Database schema initialization failed")); } });

function pruneParticipants() {
  const cutoff = Date.now() - PARTICIPANT_TTL_MS;
  for (const [sessionId, participant] of participants) if (participant.lastSeen < cutoff) participants.delete(sessionId);
}

function presenceResponse() {
  pruneParticipants();
  const onlineUsers = Array.from(participants.values()).map(p => p.name).filter((n,i,a)=>a.indexOf(n)===i).sort((a,b)=>a.localeCompare(b,"ru"));
  const typingUsers = Array.from(participants.values()).filter(p=>p.typing).map(p=>p.name).filter((n,i,a)=>a.indexOf(n)===i).sort((a,b)=>a.localeCompare(b,"ru"));
  return GetChatPresenceResponse.parse({ onlineUsers, count: onlineUsers.length, typingUsers });
}

function serializeMessage(message: ChatMessage & { authorSessionId?: string | null; replyToId?: number | null }) {
  return { id: message.id, name: message.name, text: message.text, createdAt: message.createdAt.toISOString(), authorSessionId: message.authorSessionId ?? null, replyToId: message.replyToId ?? null };
}

async function getRole(sessionId: string) {
  const [profile] = await db.select({ role: chatProfilesTable.role }).from(chatProfilesTable).where(eq(chatProfilesTable.sessionId, sessionId)).limit(1);
  return profile?.role ?? "user";
}

router.get("/chat/messages", async (req,res): Promise<void> => {
  const parsed = ListChatMessagesQueryParams.safeParse(req.query);
  if (!parsed.success) { res.status(400).json({error: parsed.error.message}); return; }
  const { afterId, limit=50 } = parsed.data;
  const messages = await db.select().from(chatMessagesTable).where(afterId === undefined ? undefined : gt(chatMessagesTable.id, afterId)).orderBy(desc(chatMessagesTable.id)).limit(limit);
  res.json(messages.reverse().map(serializeMessage));
});

router.post("/chat/messages", async (req,res): Promise<void> => {
  const body = z.object({ name:z.string().min(1).max(24), text:z.string().min(1).max(1000), sessionId:z.string().min(8).max(80), replyToId:z.number().int().positive().nullable().optional() }).safeParse(req.body);
  if (!body.success) { res.status(400).json({error:body.error.message}); return; }
  const role = await getRole(body.data.sessionId);
  if (role === "banned") { res.status(403).json({error:"Вы заблокированы."}); return; }
  const [message] = await db.insert(chatMessagesTable).values({ name:body.data.name, text:body.data.text, authorSessionId:body.data.sessionId, replyToId:body.data.replyToId ?? null }).returning();
  res.status(201).json(serializeMessage(message));
});

router.delete("/chat/messages/:id", async (req,res): Promise<void> => {
  const body = deleteBody.safeParse(req.body);
  if (!body.success) { res.status(400).json({error:body.error.message}); return; }
  const role = await getRole(body.data.sessionId);
  if (role !== "developer" && role !== "moderator") { res.status(403).json({error:"Недостаточно прав."}); return; }
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) { res.status(400).json({error:"Неверный ID."}); return; }
  await db.delete(chatMessagesTable).where(eq(chatMessagesTable.id,id));
  res.status(204).end();
});

router.get("/chat/profiles/:sessionId", async (req,res): Promise<void> => {
  const [profile] = await db.select({sessionId:chatProfilesTable.sessionId,name:chatProfilesTable.name,bio:chatProfilesTable.bio,avatar:chatProfilesTable.avatar,accent:chatProfilesTable.accent,emoji:chatProfilesTable.emoji,role:chatProfilesTable.role,createdAt:chatProfilesTable.createdAt}).from(chatProfilesTable).where(eq(chatProfilesTable.sessionId,req.params.sessionId)).limit(1);
  if (!profile) { res.status(404).json({error:"Профиль не найден."}); return; }
  res.json(profile);
});

router.put("/chat/profile", async (req,res): Promise<void> => {
  const parsed = profileBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({error:parsed.error.message}); return; }
  const data = parsed.data;
  const existing = await db.select({role:chatProfilesTable.role}).from(chatProfilesTable).where(eq(chatProfilesTable.sessionId,data.sessionId)).limit(1);
  const [profile] = await db.insert(chatProfilesTable).values({...data, avatar:data.avatar ?? null}).onConflictDoUpdate({target:chatProfilesTable.sessionId,set:{name:data.name,bio:data.bio,avatar:data.avatar ?? null,accent:data.accent,emoji:data.emoji,updatedAt:new Date()}}).returning();
  if (existing[0]?.role) (profile as any).role = existing[0].role;
  res.json(profile);
});

router.post("/chat/developer", async (req,res): Promise<void> => {
  const parsed = developerBody.safeParse(req.body);
  if (!parsed.success || !process.env.ANOCHAT_DEVELOPER_KEY || parsed.data.key !== process.env.ANOCHAT_DEVELOPER_KEY) { res.status(403).json({error:"Неверный ключ разработчика."}); return; }
  const [profile] = await db.insert(chatProfilesTable).values({sessionId:parsed.data.sessionId,name:"Разработчик",role:"developer"}).onConflictDoUpdate({target:chatProfilesTable.sessionId,set:{role:"developer",updatedAt:new Date()}}).returning();
  res.json({ok:true, role:profile.role});
});

router.post("/chat/role", async (req,res): Promise<void> => {
  const parsed = roleBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({error:parsed.error.message}); return; }
  const actorRole = await getRole(parsed.data.actorSessionId);
  if (actorRole !== "developer") { res.status(403).json({error:"Только разработчик может выдавать роли."}); return; }
  const [profile] = await db.update(chatProfilesTable).set({role:parsed.data.role,updatedAt:new Date()}).where(eq(chatProfilesTable.sessionId,parsed.data.targetSessionId)).returning();
  if (!profile) { res.status(404).json({error:"Пользователь не найден."}); return; }
  res.json({ok:true, role:profile.role});
});

router.post("/chat/join", async (req,res): Promise<void> => {
  const parsed = JoinChatBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({error:parsed.error.message}); return; }
  participants.set(parsed.data.sessionId,{name:parsed.data.name,lastSeen:Date.now(),typing:false});
  await db.insert(chatProfilesTable).values({sessionId:parsed.data.sessionId,name:parsed.data.name}).onConflictDoUpdate({target:chatProfilesTable.sessionId,set:{name:parsed.data.name,updatedAt:new Date()}});
  res.json(presenceResponse());
});
router.get("/chat/presence", (_req,res) => res.json(presenceResponse()));
router.post("/chat/typing", (req,res): void => { const parsed=UpdateChatTypingBody.safeParse(req.body); if(!parsed.success){res.status(400).json({error:parsed.error.message});return;} participants.set(parsed.data.sessionId,{name:parsed.data.name,lastSeen:Date.now(),typing:parsed.data.typing}); res.status(204).end(); });

export default router;
