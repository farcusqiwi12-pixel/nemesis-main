import { motion } from 'framer-motion';
import { SafeFrame } from '@/lib/video';
import { ChatWindow, MessageRow } from './ChatWindow';

export function Scene3() {
  return (
    <section className="scene-layer">
      <SafeFrame>
        <motion.div
          initial={{ opacity: 0, x: -24 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 28 }}
          transition={{ duration: .6 }}
          style={{ position: 'absolute', left: '8%', top: '10%', color: 'var(--color-secondary)' }}
          className="eyebrow"
        >
          02 / общая комната
        </motion.div>
        <motion.div
          initial={{ opacity: 0, scale: .75, rotate: 4 }}
          animate={{ opacity: 1, scale: 1, rotate: 1 }}
          exit={{ opacity: 0, scale: 1.15, rotate: -5 }}
          transition={{ duration: .9, ease: [0.16, 1, 0.3, 1] }}
          style={{ position: 'absolute', left: '9%', top: '20%', width: '82%' }}
        >
          <ChatWindow presence="3 сейчас здесь">
            <div className="tiny" style={{ color: 'var(--color-text-secondary)', textAlign: 'center', marginBottom: 2 }}>сегодня</div>
            <MessageRow name="мятный чай" text="кто уже здесь?" tone="coral" delay={.2} />
            <MessageRow name="Лёша" text="я. ссылка сработала" tone="sage" align="right" delay={.55} />
            <MessageRow name="соня" text="захожу" tone="butter" delay={.9} />
          </ChatWindow>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, scale: .5, rotate: -20 }}
          animate={{ opacity: 1, scale: 1, rotate: -7 }}
          exit={{ opacity: 0, scale: 1.35, rotate: 15 }}
          transition={{ delay: .75, duration: .8 }}
          style={{ position: 'absolute', right: '4%', bottom: '10%', border: '1px solid var(--color-text-primary)', background: 'var(--color-accent)', padding: '10px 14px', borderRadius: '50%', fontSize: 'clamp(10px, 2vmin, 18px)', fontWeight: 700 }}
        >
          все<br />видят
        </motion.div>
      </SafeFrame>
    </section>
  );
}