import { motion } from 'framer-motion';
import { SafeFrame } from '@/lib/video';

const asset = (name: string) => `${import.meta.env.BASE_URL}assets/${name}`;

export function Scene1() {
  return (
    <section className="scene-layer">
      <SafeFrame>
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -30 }}
          transition={{ duration: .7 }}
          style={{ position: 'absolute', left: '7%', top: '10%', color: 'var(--color-secondary)' }}
          className="eyebrow"
        >
          тихий общий чат
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: .5, rotate: -18 }}
          animate={{ opacity: 1, scale: 1, rotate: -10 }}
          exit={{ opacity: 0, scale: 1.35, rotate: 12 }}
          transition={{ delay: .16, duration: 1, ease: [0.16, 1, 0.3, 1] }}
          style={{ position: 'absolute', width: '22%', right: '8%', top: '8%' }}
        >
          <img className="sticker" src={asset('chat-sticker.png')} alt="" style={{ width: '100%', height: '100%' }} />
        </motion.div>

        <div style={{ position: 'absolute', left: '7%', top: '19%', width: '80%' }}>
          <motion.div
            initial={{ opacity: 0, y: 25 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -22, scale: 1.12 }}
            transition={{ delay: .24, duration: .85, ease: [0.16, 1, 0.3, 1] }}
            className="display"
            style={{ fontSize: 'clamp(62px, 15vmin, 170px)', lineHeight: .76, maxWidth: '72%' }}
          >
            Это,<br /><span style={{ color: 'var(--color-primary)', marginLeft: '12%' }}>аночат.</span>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ delay: .68, duration: .6 }}
            style={{ maxWidth: '46%', fontSize: 'clamp(12px, 2.6vmin, 24px)', lineHeight: 1.25, marginTop: '6%' }}
          >
            Одно место для своих.<br />Без лишнего шума.
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 35, rotate: 4 }}
          animate={{ opacity: 1, y: 0, rotate: 3 }}
          exit={{ opacity: 0, scale: .9, y: 40 }}
          transition={{ delay: .92, duration: .8, ease: [0.16, 1, 0.3, 1] }}
          style={{ position: 'absolute', right: '8%', bottom: '11%', width: '45%', padding: '4%', border: '1px solid rgba(42,39,48,.16)', background: 'rgba(250,246,237,.75)', boxShadow: '8px 9px 0 rgba(42,39,48,.07)', borderRadius: 16 }}
        >
          <div className="tiny" style={{ color: 'var(--color-secondary)' }}>одна ссылка</div>
          <div style={{ marginTop: 12, padding: '11px 13px', borderRadius: 9, background: 'var(--color-bg-muted)', fontFamily: 'var(--font-mono)', fontSize: 'clamp(9px, 1.6vmin, 14px)', whiteSpace: 'nowrap' }}>
            anochat.ru / room / 7f3a
          </div>
          <div style={{ height: 1, background: 'var(--color-primary)', width: '65%', marginTop: 14 }} />
        </motion.div>
      </SafeFrame>
    </section>
  );
}