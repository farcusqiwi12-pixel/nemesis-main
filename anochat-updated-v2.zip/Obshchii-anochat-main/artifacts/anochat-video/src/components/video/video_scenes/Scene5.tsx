import { motion } from 'framer-motion';
import { SafeFrame } from '@/lib/video';

export function Scene5() {
  return (
    <section className="scene-layer">
      <SafeFrame>
        <motion.div
          initial={{ opacity: 0, scale: .2, rotate: -20 }}
          animate={{ opacity: 1, scale: 1, rotate: -9 }}
          exit={{ opacity: 0, scale: 2.5, rotate: 18 }}
          transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1] }}
          style={{ position: 'absolute', left: '13%', top: '16%', width: '18%', aspectRatio: 1, borderRadius: '50%', background: 'var(--color-primary)', boxShadow: '0 0 0 12px rgba(227,91,79,.1)' }}
        />
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -22 }}
          transition={{ delay: .35, duration: .8, ease: [0.16, 1, 0.3, 1] }}
          style={{ position: 'absolute', left: '13%', top: '39%', maxWidth: '75%' }}
        >
          <div className="eyebrow" style={{ color: 'var(--color-secondary)', marginBottom: '6%' }}>Это, аночат.</div>
          <div className="display" style={{ fontSize: 'clamp(47px, 11.5vmin, 130px)', lineHeight: .85 }}>
            Одна ссылка.<br /><span style={{ color: 'var(--color-primary)' }}>Одна комната.</span>
          </div>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 30, rotate: 4 }}
          animate={{ opacity: 1, y: 0, rotate: 3 }}
          exit={{ opacity: 0, scale: .9, y: 34 }}
          transition={{ delay: .72, duration: .85, ease: [0.16, 1, 0.3, 1] }}
          style={{ position: 'absolute', left: '52%', bottom: '10%', width: '39%', padding: '4%', border: '1px solid rgba(42,39,48,.16)', background: 'rgba(250,246,237,.78)', borderRadius: 16, boxShadow: '7px 8px 0 rgba(42,39,48,.08)' }}
        >
          <div className="tiny" style={{ color: 'var(--color-secondary)' }}>для своих людей</div>
          <div style={{ height: 1, background: 'var(--color-primary)', width: '75%', margin: '15px 0 12px' }} />
          <div style={{ fontSize: 'clamp(11px, 2.1vmin, 20px)', lineHeight: 1.22 }}>зайди. назови себя.<br />останься на связи.</div>
        </motion.div>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ delay: 1.5, duration: .5 }}
          className="tiny"
          style={{ position: 'absolute', right: '8%', top: '10%', color: 'var(--color-text-secondary)' }}
        >
          anochat / 2024
        </motion.div>
      </SafeFrame>
    </section>
  );
}