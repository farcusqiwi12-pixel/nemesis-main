import { motion } from 'framer-motion';
import type { ReactNode } from 'react';

type ChatWindowProps = {
  children: ReactNode;
  className?: string;
  title?: string;
  presence?: string;
};

export function ChatWindow({
  children,
  className = '',
  title = 'Общая комната',
  presence = '3 сейчас здесь',
}: ChatWindowProps) {
  return (
    <motion.div
      className={`chat-window ${className}`}
      initial={{ opacity: 0, y: 24, rotate: 2 }}
      animate={{ opacity: 1, y: 0, rotate: 0 }}
      exit={{ opacity: 0, scale: .96, rotate: -2 }}
      transition={{ duration: .8, ease: [0.16, 1, 0.3, 1] }}
    >
      <div className="chat-window-top">
        <div>
          <div className="display" style={{ fontSize: 'clamp(16px, 3.1vmin, 30px)', lineHeight: 1 }}>{title}</div>
          <div className="tiny" style={{ color: 'var(--color-text-secondary)', marginTop: 5 }}>сообщения видны всем по этой ссылке</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
          <span style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--color-secondary)', display: 'block' }} />
          <span className="tiny" style={{ color: 'var(--color-secondary)' }}>{presence}</span>
        </div>
      </div>
      <div style={{ padding: 'clamp(15px, 3vmin, 28px)', display: 'grid', gap: 'clamp(10px, 1.8vmin, 17px)' }}>
        {children}
      </div>
      <div style={{ borderTop: '1px solid rgba(42,39,48,.11)', margin: '0 clamp(15px, 3vmin, 28px)', padding: '12px 0 15px', display: 'flex', gap: 8, alignItems: 'center' }}>
        <div style={{ flex: 1, height: 30, borderRadius: 9, background: 'rgba(42,39,48,.055)', border: '1px solid rgba(42,39,48,.08)' }} />
        <div style={{ width: 30, height: 30, borderRadius: 9, background: 'var(--color-primary)' }} />
      </div>
    </motion.div>
  );
}

export function MessageRow({
  name,
  text,
  tone = 'cream',
  align = 'left',
  delay = 0,
}: {
  name: string;
  text: string;
  tone?: 'coral' | 'sage' | 'butter' | 'cream';
  align?: 'left' | 'right';
  delay?: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, x: align === 'right' ? 18 : -18, scale: .94 }}
      animate={{ opacity: 1, x: 0, scale: 1 }}
      exit={{ opacity: 0, x: align === 'right' ? -12 : 12, scale: .96 }}
      transition={{ delay, duration: .5, ease: [0.22, 1, 0.36, 1] }}
      style={{ justifySelf: align === 'right' ? 'end' : 'start', display: 'grid', gap: 5 }}
    >
      <div className="tiny" style={{ color: 'var(--color-text-secondary)', marginLeft: align === 'right' ? 'auto' : 3 }}>{name}</div>
      <div className={`chat-bubble ${tone}`}>{text}</div>
    </motion.div>
  );
}