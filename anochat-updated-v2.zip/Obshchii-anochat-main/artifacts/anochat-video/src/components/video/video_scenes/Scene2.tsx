import { motion } from 'framer-motion';
import { SafeFrame } from '@/lib/video';

export function Scene2() {
  return (
    <section className="scene-layer">
      <SafeFrame>
        <motion.div
          initial={{ opacity: 0, x: -24 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 28 }}
          transition={{ duration: .6 }}
          style={{ position: 'absolute', left: '8%', top: '10%', color: 'var(--color-primary)' }}
          className="eyebrow"
        >
          01 / вход без регистрации
        </motion.div>
        <motion.div
          initial={{ opacity: 0, scale: .75, rotate: -5 }}
          animate={{ opacity: 1, scale: 1, rotate: -2 }}
          exit={{ opacity: 0, scale: 1.22, rotate: 5 }}
          transition={{ delay: .12, duration: .9, ease: [0.16, 1, 0.3, 1] }}
          style={{ position: 'absolute', left: '13%', top: '22%', width: '74%', height: '57%', padding: '8%', border: '1.5px solid var(--color-text-primary)', background: 'rgba(250,246,237,.9)', borderRadius: 25, boxShadow: '12px 12px 0 var(--color-accent)' }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: '7%' }}>
            <div style={{ width: 36, height: 36, borderRadius: 12, background: 'var(--color-primary)' }} />
            <div className="display" style={{ fontSize: 'clamp(20px, 4vmin, 40px)' }}>Кто вы сегодня?</div>
          </div>
          <div className="tiny" style={{ color: 'var(--color-text-secondary)', marginBottom: 8 }}>имя в чате</div>
          <div style={{ border: '1px solid var(--color-text-primary)', borderRadius: 11, padding: 'clamp(12px, 2.3vmin, 20px)', fontSize: 'clamp(15px, 3.4vmin, 34px)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span>мятный чай</span>
            <motion.span
              animate={{ opacity: [1, 0, 1] }}
              transition={{ duration: .9, repeat: Infinity }}
              style={{ width: 2, height: '1.1em', background: 'var(--color-primary)', display: 'block' }}
            />
          </div>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ delay: 1, duration: .5 }}
            style={{ marginTop: '7%', background: 'var(--color-primary)', color: 'var(--color-text-inverse)', borderRadius: 11, padding: 'clamp(12px, 2.1vmin, 18px)', textAlign: 'center', fontWeight: 700, fontSize: 'clamp(11px, 2vmin, 18px)' }}
          >
            войти в аночат ↗
          </motion.div>
        </motion.div>
        <motion.p
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -15 }}
          transition={{ delay: 1.25, duration: .6 }}
          style={{ position: 'absolute', left: '15%', bottom: '10%', margin: 0, fontSize: 'clamp(11px, 2vmin, 18px)', color: 'var(--color-text-secondary)' }}
        >
          настоящее, выдуманное — любое имя.
        </motion.p>
      </SafeFrame>
    </section>
  );
}