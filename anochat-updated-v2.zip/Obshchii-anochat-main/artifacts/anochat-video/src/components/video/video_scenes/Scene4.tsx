import { motion } from 'framer-motion';
import { SafeFrame } from '@/lib/video';
import { ChatWindow, MessageRow } from './ChatWindow';

export function Scene4() {
  return (
    <section className="scene-layer">
      <SafeFrame>
        <motion.div
          initial={{ opacity: 0, x: -24 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 28 }}
          transition={{ duration: .6 }}
          style={{ position: 'absolute', left: '8%', top: '10%', color: 'var(--color-primary)' }}
          className="eyebrow"
        >
          03 / разговор без лишнего
        </motion.div>
        <motion.div
          initial={{ opacity: 0, scale: .82, x: 20, rotate: -4 }}
          animate={{ opacity: 1, scale: 1, x: 0, rotate: -1 }}
          exit={{ opacity: 0, scale: 1.12, x: -15, rotate: 4 }}
          transition={{ duration: .9, ease: [0.16, 1, 0.3, 1] }}
          style={{ position: 'absolute', left: '9%', top: '18%', width: '82%' }}
        >
          <ChatWindow presence="4 сейчас здесь">
            <MessageRow name="соня" text="предлагаю в пятницу на дачу" tone="butter" delay={.12} />
            <MessageRow name="Лёша" text="беру колонку" tone="sage" align="right" delay={.4} />
            <MessageRow name="мятный чай" text="и я. всё, теперь точно собираемся" tone="coral" delay={.7} />
            <motion.div
              initial={{ opacity: 0, width: 0 }}
              animate={{ opacity: 1, width: '58%' }}
              transition={{ delay: 1.1, duration: .6 }}
              style={{ height: 1, background: 'var(--color-primary)', marginTop: 3 }}
            />
          </ChatWindow>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -18 }}
          transition={{ delay: 1.35, duration: .6 }}
          style={{ position: 'absolute', left: '12%', bottom: '9%', display: 'flex', alignItems: 'center', gap: 9, color: 'var(--color-secondary)' }}
        >
          <span style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--color-secondary)' }} />
          <span className="tiny">история остаётся здесь для всех</span>
        </motion.div>
      </SafeFrame>
    </section>
  );
}