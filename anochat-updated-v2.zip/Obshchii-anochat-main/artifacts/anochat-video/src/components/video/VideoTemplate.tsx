import {
  VideoCanvas,
  type VideoAspectRatio,
  useVideoPlayer,
} from '@/lib/video';
import { AnimatePresence, motion } from 'framer-motion';
import { Scene1 } from './video_scenes/Scene1';
import { Scene2 } from './video_scenes/Scene2';
import { Scene3 } from './video_scenes/Scene3';
import { Scene4 } from './video_scenes/Scene4';
import { Scene5 } from './video_scenes/Scene5';

const SCENE_DURATIONS = {
  opening: 3200,
  enter: 3600,
  room: 4200,
  conversation: 4200,
  close: 4400,
};

const VIDEO_ASPECT_RATIO: VideoAspectRatio = '1:1';

export default function VideoTemplate() {
  const { currentScene } = useVideoPlayer({
    durations: SCENE_DURATIONS,
  });

  return (
    <VideoCanvas
      className="video-root"
      aspectRatio={VIDEO_ASPECT_RATIO}
      style={{ background: 'var(--color-bg-light)' }}
    >
      <div
        className="paper-grain"
        style={{ backgroundImage: `url(${import.meta.env.BASE_URL}assets/room-paper-texture.png)` }}
      />
      <div className="ink-noise" />

      <motion.div
        aria-hidden="true"
        style={{
          position: 'absolute',
          width: '42vmin',
          height: '42vmin',
          borderRadius: '50%',
          background: 'var(--color-primary)',
          opacity: .10,
          filter: 'blur(1px)',
          zIndex: 1,
        }}
        animate={{
          x: ['-16%', '56%', '8%', '64%', '-10%'][currentScene],
          y: ['18%', '-4%', '64%', '10%', '52%'][currentScene],
          scale: [1.1, .75, 1.4, .92, 1.2][currentScene],
        }}
        transition={{ duration: 1.25, ease: [0.16, 1, 0.3, 1] }}
      />
      <motion.div
        aria-hidden="true"
        style={{
          position: 'absolute',
          width: '55vmin',
          height: '55vmin',
          border: '1px solid rgba(104,139,120,.36)',
          borderRadius: '50%',
          zIndex: 1,
        }}
        animate={{
          x: ['52%', '-18%', '36%', '-10%', '54%'][currentScene],
          y: ['60%', '4%', '-18%', '42%', '20%'][currentScene],
          rotate: [0, 38, 86, 150, 220][currentScene],
          scale: [.85, 1.15, .72, 1.18, .9][currentScene],
        }}
        transition={{ duration: 1.55, ease: [0.16, 1, 0.3, 1] }}
      />
      <motion.div
        aria-hidden="true"
        style={{
          position: 'absolute',
          height: 1,
          background: 'var(--color-primary)',
          zIndex: 2,
          transformOrigin: 'left center',
        }}
        animate={{
          left: ['9%', '7%', '58%', '13%', '12%'][currentScene],
          top: ['17%', '82%', '14%', '76%', '34%'][currentScene],
          width: ['42%', '78%', '28%', '62%', '50%'][currentScene],
          rotate: [0, -8, 2, 7, -2][currentScene],
          opacity: [1, .65, .8, .6, .75][currentScene],
        }}
        transition={{ duration: .9, ease: [0.22, 1, 0.36, 1] }}
      />

      <motion.div
        aria-hidden="true"
        style={{ position: 'absolute', right: '8%', bottom: '7%', zIndex: 2, color: 'var(--color-text-secondary)' }}
        animate={{ rotate: [0, 7, -4, 5, 0][currentScene], y: [0, -8, 5, -3, 0][currentScene] }}
        transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1] }}
        className="tiny"
      >
        общий чат / без регистрации
      </motion.div>

      <AnimatePresence mode="sync">
        {currentScene === 0 && <Scene1 key="opening" />}
        {currentScene === 1 && <Scene2 key="enter" />}
        {currentScene === 2 && <Scene3 key="room" />}
        {currentScene === 3 && <Scene4 key="conversation" />}
        {currentScene === 4 && <Scene5 key="close" />}
      </AnimatePresence>
    </VideoCanvas>
  );
}
