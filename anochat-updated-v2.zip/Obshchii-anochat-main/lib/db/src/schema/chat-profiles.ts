import { pgTable, text, timestamp } from "drizzle-orm/pg-core";

export const chatProfilesTable = pgTable("chat_profiles", {
  sessionId: text("session_id").primaryKey(),
  name: text("name").notNull(),
  bio: text("bio").notNull().default(""),
  avatar: text("avatar"),
  accent: text("accent").notNull().default("#d94b72"),
  emoji: text("emoji").notNull().default("🙂"),
  role: text("role").notNull().default("user"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type ChatProfile = typeof chatProfilesTable.$inferSelect;
