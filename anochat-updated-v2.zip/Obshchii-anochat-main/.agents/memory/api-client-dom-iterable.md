---
name: API client DOM iterable
description: TypeScript API client generation relies on iterable DOM collection types.
---

The generated API client uses `Headers.entries()`, so its TypeScript project must include both `dom` and `dom.iterable` libraries.

**Why:** Orval output typechecks against `Headers.entries()` and fails with only the base DOM library, even though the generated client itself is valid.

**How to apply:** When adding or regenerating API client code in this workspace, preserve `dom.iterable` in the API client's tsconfig.