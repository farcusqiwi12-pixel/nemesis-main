# Общий аночат

Публичный анонимный чат по одной ссылке: участники выбирают имя, видят общую историю и переписываются в комнате.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/anochat` — основной React-интерфейс входа и общей комнаты.
- `artifacts/api-server/src/routes/chat.ts` — API истории сообщений и присутствия.
- `lib/db/src/schema/chat-messages.ts` — таблица сохранённых сообщений.
- `lib/api-spec/openapi.yaml` — контракт API и источник сгенерированных хуков.

## Architecture decisions

- Имена участников анонимные и не требуют регистрации.
- Сообщения хранятся в PostgreSQL, а интерфейс обновляет историю и присутствие с коротким интервалом опроса.
- Присутствие хранится в памяти API с TTL; закрытая вкладка автоматически исчезает из списка после истечения TTL.

## Product

- Вход в общую комнату по имени.
- Отправка сообщений с сохранением истории для всех участников.
- Отображение количества людей в комнате, пустого состояния, ошибок загрузки и офлайн-состояния.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
